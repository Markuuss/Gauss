﻿namespace Gauss
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.InfoButton = new System.Windows.Forms.Button();
            this.ResultButton = new System.Windows.Forms.Button();
            this.InputIntervalFromText = new System.Windows.Forms.Label();
            this.InputIntervalToText = new System.Windows.Forms.Label();
            this.InputIntervalFrom = new System.Windows.Forms.TextBox();
            this.InputIntervalTo = new System.Windows.Forms.TextBox();
            this.ResultText = new System.Windows.Forms.Label();
            this.DerivativeText = new System.Windows.Forms.Label();
            this.Chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.NumberOfPoints = new System.Windows.Forms.TextBox();
            this.NumberOfPointsText = new System.Windows.Forms.Label();
            this.InputIntervalText = new System.Windows.Forms.Label();
            this.IntegralText = new System.Windows.Forms.Label();
            this.Derivative = new System.Windows.Forms.Label();
            this.Integral = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Chart)).BeginInit();
            this.SuspendLayout();
            // 
            // InfoButton
            // 
            this.InfoButton.BackColor = System.Drawing.Color.LemonChiffon;
            this.InfoButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.InfoButton.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.InfoButton.Location = new System.Drawing.Point(12, 407);
            this.InfoButton.Name = "InfoButton";
            this.InfoButton.Size = new System.Drawing.Size(75, 23);
            this.InfoButton.TabIndex = 0;
            this.InfoButton.Text = "Справка";
            this.InfoButton.UseVisualStyleBackColor = false;
            this.InfoButton.Click += new System.EventHandler(this.InfoButton_Click);
            // 
            // ResultButton
            // 
            this.ResultButton.BackColor = System.Drawing.Color.OliveDrab;
            this.ResultButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ResultButton.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ResultButton.ForeColor = System.Drawing.Color.Yellow;
            this.ResultButton.Location = new System.Drawing.Point(55, 200);
            this.ResultButton.Name = "ResultButton";
            this.ResultButton.Size = new System.Drawing.Size(223, 33);
            this.ResultButton.TabIndex = 1;
            this.ResultButton.Text = "Результат";
            this.ResultButton.UseVisualStyleBackColor = false;
            this.ResultButton.Click += new System.EventHandler(this.ResultButton_Click);
            // 
            // InputIntervalFromText
            // 
            this.InputIntervalFromText.AutoSize = true;
            this.InputIntervalFromText.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputIntervalFromText.Location = new System.Drawing.Point(52, 69);
            this.InputIntervalFromText.Name = "InputIntervalFromText";
            this.InputIntervalFromText.Size = new System.Drawing.Size(22, 15);
            this.InputIntervalFromText.TabIndex = 2;
            this.InputIntervalFromText.Text = "От";
            // 
            // InputIntervalToText
            // 
            this.InputIntervalToText.AutoSize = true;
            this.InputIntervalToText.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputIntervalToText.Location = new System.Drawing.Point(175, 69);
            this.InputIntervalToText.Name = "InputIntervalToText";
            this.InputIntervalToText.Size = new System.Drawing.Size(24, 15);
            this.InputIntervalToText.TabIndex = 3;
            this.InputIntervalToText.Text = "До";
            // 
            // InputIntervalFrom
            // 
            this.InputIntervalFrom.Location = new System.Drawing.Point(55, 85);
            this.InputIntervalFrom.Name = "InputIntervalFrom";
            this.InputIntervalFrom.Size = new System.Drawing.Size(100, 20);
            this.InputIntervalFrom.TabIndex = 4;
            this.InputIntervalFrom.Text = "0";
            // 
            // InputIntervalTo
            // 
            this.InputIntervalTo.Location = new System.Drawing.Point(178, 85);
            this.InputIntervalTo.Name = "InputIntervalTo";
            this.InputIntervalTo.Size = new System.Drawing.Size(100, 20);
            this.InputIntervalTo.TabIndex = 5;
            this.InputIntervalTo.Text = "1";
            // 
            // ResultText
            // 
            this.ResultText.AutoSize = true;
            this.ResultText.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ResultText.Location = new System.Drawing.Point(331, 329);
            this.ResultText.Name = "ResultText";
            this.ResultText.Size = new System.Drawing.Size(149, 15);
            this.ResultText.TabIndex = 6;
            this.ResultText.Text = "Результат вычисления";
            // 
            // DerivativeText
            // 
            this.DerivativeText.AutoSize = true;
            this.DerivativeText.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.DerivativeText.Location = new System.Drawing.Point(331, 359);
            this.DerivativeText.Name = "DerivativeText";
            this.DerivativeText.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DerivativeText.Size = new System.Drawing.Size(127, 15);
            this.DerivativeText.TabIndex = 7;
            this.DerivativeText.Text = "Производная равна:";
            // 
            // Chart
            // 
            chartArea4.Name = "ChartArea1";
            this.Chart.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.Chart.Legends.Add(legend4);
            this.Chart.Location = new System.Drawing.Point(334, 12);
            this.Chart.Name = "Chart";
            this.Chart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.EarthTones;
            series4.ChartArea = "ChartArea1";
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.Chart.Series.Add(series4);
            this.Chart.Size = new System.Drawing.Size(454, 300);
            this.Chart.TabIndex = 8;
            this.Chart.Text = "chart1";
            // 
            // NumberOfPoints
            // 
            this.NumberOfPoints.Location = new System.Drawing.Point(55, 149);
            this.NumberOfPoints.Name = "NumberOfPoints";
            this.NumberOfPoints.Size = new System.Drawing.Size(100, 20);
            this.NumberOfPoints.TabIndex = 10;
            this.NumberOfPoints.Text = "11";
            // 
            // NumberOfPointsText
            // 
            this.NumberOfPointsText.AutoSize = true;
            this.NumberOfPointsText.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.NumberOfPointsText.Location = new System.Drawing.Point(52, 131);
            this.NumberOfPointsText.Name = "NumberOfPointsText";
            this.NumberOfPointsText.Size = new System.Drawing.Size(168, 15);
            this.NumberOfPointsText.TabIndex = 9;
            this.NumberOfPointsText.Text = "Введите количество точек";
            // 
            // InputIntervalText
            // 
            this.InputIntervalText.AutoSize = true;
            this.InputIntervalText.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.InputIntervalText.Location = new System.Drawing.Point(52, 44);
            this.InputIntervalText.Name = "InputIntervalText";
            this.InputIntervalText.Size = new System.Drawing.Size(223, 15);
            this.InputIntervalText.TabIndex = 11;
            this.InputIntervalText.Text = "Введите интервал для вычисления";
            // 
            // IntegralText
            // 
            this.IntegralText.AutoSize = true;
            this.IntegralText.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.IntegralText.Location = new System.Drawing.Point(331, 384);
            this.IntegralText.Name = "IntegralText";
            this.IntegralText.Size = new System.Drawing.Size(102, 15);
            this.IntegralText.TabIndex = 12;
            this.IntegralText.Text = "Интеграл равен:";
            // 
            // Derivative
            // 
            this.Derivative.AutoSize = true;
            this.Derivative.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Derivative.Location = new System.Drawing.Point(464, 359);
            this.Derivative.Name = "Derivative";
            this.Derivative.Size = new System.Drawing.Size(69, 15);
            this.Derivative.TabIndex = 13;
            this.Derivative.Text = "Результат";
            // 
            // Integral
            // 
            this.Integral.AutoSize = true;
            this.Integral.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Integral.Location = new System.Drawing.Point(439, 384);
            this.Integral.Name = "Integral";
            this.Integral.Size = new System.Drawing.Size(69, 15);
            this.Integral.TabIndex = 14;
            this.Integral.Text = "Результат";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 442);
            this.Controls.Add(this.Integral);
            this.Controls.Add(this.Derivative);
            this.Controls.Add(this.IntegralText);
            this.Controls.Add(this.InputIntervalText);
            this.Controls.Add(this.NumberOfPoints);
            this.Controls.Add(this.NumberOfPointsText);
            this.Controls.Add(this.Chart);
            this.Controls.Add(this.DerivativeText);
            this.Controls.Add(this.ResultText);
            this.Controls.Add(this.InputIntervalTo);
            this.Controls.Add(this.InputIntervalFrom);
            this.Controls.Add(this.InputIntervalToText);
            this.Controls.Add(this.InputIntervalFromText);
            this.Controls.Add(this.ResultButton);
            this.Controls.Add(this.InfoButton);
            this.Name = "MainForm";
            this.Text = "Вычисление производных и интегралов по формуле Гаусса";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Chart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button InfoButton;
        private System.Windows.Forms.Button ResultButton;
        private System.Windows.Forms.Label InputIntervalFromText;
        private System.Windows.Forms.Label InputIntervalToText;
        private System.Windows.Forms.TextBox InputIntervalFrom;
        private System.Windows.Forms.TextBox InputIntervalTo;
        private System.Windows.Forms.Label ResultText;
        private System.Windows.Forms.Label DerivativeText;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chart;
        private System.Windows.Forms.TextBox NumberOfPoints;
        private System.Windows.Forms.Label NumberOfPointsText;
        private System.Windows.Forms.Label InputIntervalText;
        private System.Windows.Forms.Label IntegralText;
        private System.Windows.Forms.Label Derivative;
        private System.Windows.Forms.Label Integral;
    }
}

