﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using MathNet.Numerics.Integration;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Gauss
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();

            Chart.Series.Clear();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void ResultButton_Click(object sender, EventArgs e)
        {
            try
            {
                double IntervalFrom = double.Parse(InputIntervalFrom.Text);
                double IntervalTo = double.Parse(InputIntervalTo.Text);
                double OfPoints = double.Parse(NumberOfPoints.Text);
                // Получаем значения из текстовых полей
                double a = double.Parse(InputIntervalFrom.Text);
                double b = double.Parse(InputIntervalTo.Text);
                int n = int.Parse(NumberOfPoints.Text);

                // Вычисляем узлы интегрирования и весовые коэффициенты
                double[] x = new double[n];
                double[] w = new double[n];
                GaussNodesWeights(a, b, n, out x, out w);

                // Вычисляем интеграл

                double result = 0.0;
                for (int i = 0; i < n; i++)
                {
                    double xi = ((b - a) / 2.0) * x[i] + ((a + b) / 2.0);
                    double wi = ((b - a) / 2.0) * w[i];
                    double fi;
                    try
                    {
                        fi = f(xi);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error evaluating f(x) for x = {xi}: {ex.Message}");
                        return;
                    }
                    result += wi * fi;
                }
                Integral.Text = result.ToString("F4");

                double x0 = 0.5; // точка, в которой мы хотим найти производную
                double dfdx = df(x0); // значение производной в точке x0
                Derivative.Text = dfdx.ToString("F4");

                double[] xValues = new double[1001];
                double step = (b - a) / 1000.0;
                for (int i = 0; i <= 1000; i++)
                {
                    xValues[i] = a + i * step;
                }

                // Вычисляем значение функции в каждой точке диапазона x
                double[] yValues = new double[1001];
                double[] dyValues = new double[1001];
                for (int i = 0; i <= 1000; i++)
                {
                    yValues[i] = f(xValues[i]);
                    dyValues[i] = df(xValues[i]);
                }

                // Создаем объект Series и добавляем в него точки (x, y)
                Series series = new Series();
                series.ChartType = SeriesChartType.Line;
                for (int i = 0; i <= 1000; i++)
                {
                    series.Points.AddXY(xValues[i], yValues[i]);
                }
                series.Name = "Интеграл";

                // Создаем объект Series и добавляем в него точки (x, dy)
                Series derivativeSeries = new Series();
                derivativeSeries.ChartType = SeriesChartType.Line;
                for (int i = 0; i <= 1000; i++)
                {
                    derivativeSeries.Points.AddXY(xValues[i], dyValues[i]);
                }
                derivativeSeries.Name = "Производная";

                // Добавляем объекты Series в элемент Chart и обновляем график
                Chart.Series.Clear();
                Chart.Series.Add(series);
                Chart.Series.Add(derivativeSeries);
                Chart.ChartAreas[0].RecalculateAxesScale();
                Chart.Invalidate();

            }
            catch (Exception)
            {
                MessageBox.Show("Вы ввели не числовой формат", "Предупрежление!", MessageBoxButtons.OK);
            }
        }

        private static double f(double x)
        {
            // здесь задаем функцию f(x) для интегрирования
            return Math.Exp(-1 * x * x);
        }

        private static void GaussNodesWeights(double a, double b, int n, out double[] x, out double[] w)
        {
            var gl = new GaussLegendreRule(a, b, n);
            x = gl.Abscissas.Select(t => (b - a) / 2.0 * t + (b + a) / 2.0).ToArray();
            w = gl.Weights.Select(t => (b - a) / 2.0 * t).ToArray();
        }

        private static double df(double x)
        {
            // здесь задаем производную функции f(x) для интегрирования
            return -2 * x * Math.Exp(-1 * x * x);
        }


        private void InfoButton_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, "Info.chm");
        }
    }
}
